from src import CreateAudio

import librosa
import numpy as np

def chooseAction():
    arr = []
    for i in range(1,9):
        x, sr = librosa.load("../wav/trai%s.wav" % i)
        mfcc = librosa.feature.mfcc(x, sr)
        arr.append(mfcc)

    for i in range(1,9):
        x, sr = librosa.load("../wav/phai%s.wav" % i)
        mfcc = librosa.feature.mfcc(x, sr)
        arr.append(mfcc)

    for i in range(1,9):
        x, sr = librosa.load("../wav/tien%s.wav" % i)
        mfcc = librosa.feature.mfcc(x, sr)
        arr.append(mfcc)

    for i in range(1,9):
        x, sr = librosa.load("../wav/lui%s.wav" % i)
        mfcc = librosa.feature.mfcc(x, sr)
        arr.append(mfcc)

    test = CreateAudio.Audio()
    test.createAudio("../wav/test.wav")
    x, sr = librosa.load("../wav/test.wav")
    mfcc = librosa.feature.mfcc(x, sr)
    delta = []
    for i in range(len(arr)):
        delta.append(np.linalg.norm(mfcc - arr[i]))
    min1 = min(delta)
    print(delta)
    print(min1)
    print((delta.index(min1)))


chooseAction()