import librosa
import numpy as np
import IPython.display
import matplotlib.pyplot as plt
from scipy import signal
#from __future__ import division
v, vr = librosa.load("../wav/test.wav")
s, sr = librosa.load("../wav/tren1.wav")
print(v.shape)
print(s.shape)
# Để tiện cho việc phân tích và so sánh các thành phần thành số , chúng ta cho số mẫu trong 2 file này bằng nhau.
# Trong thực tế  các bạn có thể  tùy ý
v = v[:70000]
s = s[:70000]
#Biến đổi fft
v_fft = np.fft.fft(v)
# Tính biên độ
v_amplitude = np.abs(v_fft)
# Vẽ phổ biên độ
plt.figure(figsize=(30,5))
plt.plot(v_amplitude[:10000])
plt.title("Vuvuzela Amplitude Spectrum")

# Tương tự đối với file speech.wav
s_fft = np.fft.fft(s)
s_amplitude = np.abs(s_fft)
plt.figure(figsize=(30,5))
plt.plot(s_amplitude[:10000])
plt.title("Speech Amplittude Spectrum")